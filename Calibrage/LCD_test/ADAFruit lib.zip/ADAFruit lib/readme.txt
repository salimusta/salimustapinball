This example works with UNO and MEGA2560 in combination with mcfriend ili9488 tft shield. 
The xy ratio is not correct but for this demo it's ok.

Close Arduino IDE
Copy the folders Adafruit_* to your library directory folder (C:\programfiles\arduino\library)

Copy the folder tftfpaint2_9327 to your desktop, open the folder, doubleclick should open Arduino ide with the sketch.
Select the UNO board and COM-port
Compile and upload.

I 